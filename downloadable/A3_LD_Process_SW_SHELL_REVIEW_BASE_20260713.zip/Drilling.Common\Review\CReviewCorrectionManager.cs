using System.Globalization;
using Drilling.Common.Station;

namespace Drilling.Common.Review;

/// <summary>
/// Review 측정값이 어떤 목적으로 수집되었는지 구분한다.
/// 요구사항의 0선 방어, Fine/Rough/Simple 보정, APC 보정 흐름을 같은 데이터 모델로 묶기 위한 기준값이다.
/// </summary>
public enum EN_REVIEW_MEASUREMENT_MODE
{
    ZeroLineDefense,
    FineCorrection,
    RoughCorrection,
    SimpleCorrection,
    ApcCorrection,
    RemoteInspection
}

/// <summary>
/// 보정값이 어디에서 왔는지 추적하기 위한 출처값이다.
/// 운영 중에는 같은 Offset이라도 Review Camera, APC, 수동 입력, Align 결과의 신뢰도와 적용 정책이 다르다.
/// </summary>
public enum EN_REVIEW_OFFSET_SOURCE
{
    ReviewCamera,
    ApcFile,
    ManualKeyIn,
    AlignResult,
    Simulation
}

/// <summary>
/// Review 장비가 한 좌표를 측정한 결과를 표현한다.
/// Design/Process/Review 좌표를 함께 들고 가는 이유는 좌표계 변환 기준이 확정되기 전에도 데이터가 어디서 왔는지 설명할 수 있게 하기 위해서다.
/// </summary>
public sealed record ST_REVIEW_MEASUREMENT_POINT(
    string PointId,
    int HeadNo,
    string CellId,
    double DesignX,
    double DesignY,
    double ProcessX,
    double ProcessY,
    double ReviewX,
    double ReviewY,
    double MeasuredX,
    double MeasuredY,
    double ErrorX,
    double ErrorY,
    double ToleranceX,
    double ToleranceY,
    int BeamNo,
    bool IsUsed,
    DateTimeOffset MeasuredAt);

/// <summary>
/// 하나의 기판 또는 공정 사이클에서 모은 Review 측정 묶음이다.
/// 실제 Vision/APC I/F가 붙으면 파일 또는 통신 메시지 한 건이 이 record로 변환된다.
/// </summary>
public sealed record ST_REVIEW_MEASUREMENT_BATCH(
    string BatchId,
    string ProcessId,
    string RecipeId,
    string ProductId,
    EN_REVIEW_MEASUREMENT_MODE Mode,
    EN_REVIEW_OFFSET_SOURCE Source,
    IReadOnlyList<ST_REVIEW_MEASUREMENT_POINT> Points,
    DateTimeOffset CreatedAt);

/// <summary>
/// Review 오차를 Offset으로 바꿀 때 사용하는 정책값이다.
/// Gain은 보정 반영 비율, MaxAbsOffset은 한 번에 움직일 수 있는 최대 보정량, MinSampleCount는 최소 측정점 개수다.
/// </summary>
public sealed record ST_REVIEW_OFFSET_POLICY(
    double GainX,
    double GainY,
    double MaxAbsOffsetX,
    double MaxAbsOffsetY,
    int MinSampleCount,
    bool AccumulateWithCurrentOffset,
    bool ApplyToNextProcessPlan);

/// <summary>
/// Head별로 계산된 최종 보정값이다.
/// OffsetX/Y는 다음 ST_PROCESS_PLAN의 Head Offset 파라미터에 반영되고, Theta는 추후 회전 보정 확장 지점으로 남긴다.
/// </summary>
public sealed record ST_REVIEW_HEAD_OFFSET(
    int HeadNo,
    double OffsetX,
    double OffsetY,
    double Theta,
    int SampleCount,
    EN_REVIEW_OFFSET_SOURCE Source,
    DateTimeOffset CreatedAt);

/// <summary>
/// Review 측정 묶음을 보정값으로 계산한 결과다.
/// IsApplicable이 false이면 샘플 부족, 옵션 비활성화, 허용범위 초과 등으로 실제 Plan 반영을 막는다.
/// </summary>
public sealed record ST_REVIEW_CORRECTION_RESULT(
    string BatchId,
    bool IsApplicable,
    string Message,
    IReadOnlyList<ST_REVIEW_HEAD_OFFSET> HeadOffsets,
    ST_REVIEW_OFFSET_POLICY Policy,
    DateTimeOffset CreatedAt);

public interface IReviewCorrectionManager
{
    ST_REVIEW_OFFSET_POLICY CreatePolicy(IReadOnlyDictionary<string, string> parameters);

    ST_REVIEW_CORRECTION_RESULT Calculate(
        ST_REVIEW_MEASUREMENT_BATCH batch,
        ST_REVIEW_OFFSET_POLICY policy);

    ST_PROCESS_PLAN ApplyToProcessPlan(
        ST_PROCESS_PLAN processPlan,
        ST_REVIEW_CORRECTION_RESULT correction);
}

/// <summary>
/// Review 측정값을 다음 가공에 적용할 Head별 Offset으로 바꾸는 base 구현이다.
/// 현재 프로젝트에는 실제 Review Camera/APC 통신이 없으므로, 이 클래스는 "어떤 데이터를 받아 어떻게 보정값으로 구조화할지"를 명확히 보여주는 기준 코드다.
/// </summary>
public sealed class CReviewCorrectionManager : IReviewCorrectionManager
{
    public ST_REVIEW_OFFSET_POLICY CreatePolicy(IReadOnlyDictionary<string, string> parameters)
    {
        return new ST_REVIEW_OFFSET_POLICY(
            ReadDouble(parameters, "REVIEW_OFFSET_GAIN_X", 1.0),
            ReadDouble(parameters, "REVIEW_OFFSET_GAIN_Y", 1.0),
            ReadDouble(parameters, "REVIEW_OFFSET_MAX_X", 0.050),
            ReadDouble(parameters, "REVIEW_OFFSET_MAX_Y", 0.050),
            Math.Max(1, ReadInt(parameters, "REVIEW_OFFSET_MIN_SAMPLE", 1)),
            ReadBool(parameters, "REVIEW_OFFSET_ACCUMULATE", true),
            ReadBool(parameters, "REVIEW_OFFSET_APPLY_TO_NEXT_PLAN", true));
    }

    public ST_REVIEW_CORRECTION_RESULT Calculate(
        ST_REVIEW_MEASUREMENT_BATCH batch,
        ST_REVIEW_OFFSET_POLICY policy)
    {
        var offsets = batch.Points
            .Where(point => point.IsUsed)
            .GroupBy(point => point.HeadNo)
            .Select(group => CreateHeadOffset(group.Key, group.ToArray(), batch.Source, policy))
            .Where(offset => offset.SampleCount >= policy.MinSampleCount)
            .OrderBy(offset => offset.HeadNo)
            .ToArray();

        var isApplicable = policy.ApplyToNextProcessPlan && offsets.Length > 0;
        var message = isApplicable
            ? $"Review correction ready. HeadOffsets={offsets.Length}"
            : "Review correction skipped. Policy disabled or not enough review samples.";

        return new ST_REVIEW_CORRECTION_RESULT(
            batch.BatchId,
            isApplicable,
            message,
            offsets,
            policy,
            DateTimeOffset.Now);
    }

    public ST_PROCESS_PLAN ApplyToProcessPlan(
        ST_PROCESS_PLAN processPlan,
        ST_REVIEW_CORRECTION_RESULT correction)
    {
        if (!correction.IsApplicable)
        {
            return processPlan;
        }

        var parameters = new Dictionary<string, string>(
            processPlan.Parameters,
            StringComparer.OrdinalIgnoreCase);

        parameters["REVIEW_OFFSET_BATCH_ID"] = correction.BatchId;
        parameters["REVIEW_OFFSET_APPLIED_AT"] = correction.CreatedAt.ToString("O", CultureInfo.InvariantCulture);
        parameters["REVIEW_OFFSET_MESSAGE"] = correction.Message;

        foreach (var offset in correction.HeadOffsets)
        {
            var prefix = $"H{offset.HeadNo:00}";
            var currentX = ReadDouble(parameters, $"{prefix}_OFFSET_X", 0.0);
            var currentY = ReadDouble(parameters, $"{prefix}_OFFSET_Y", 0.0);
            var nextX = correction.Policy.AccumulateWithCurrentOffset ? currentX + offset.OffsetX : offset.OffsetX;
            var nextY = correction.Policy.AccumulateWithCurrentOffset ? currentY + offset.OffsetY : offset.OffsetY;

            parameters[$"{prefix}_OFFSET_X"] = Format(nextX);
            parameters[$"{prefix}_OFFSET_Y"] = Format(nextY);
            parameters[$"{prefix}_REVIEW_OFFSET_X"] = Format(offset.OffsetX);
            parameters[$"{prefix}_REVIEW_OFFSET_Y"] = Format(offset.OffsetY);
            parameters[$"{prefix}_REVIEW_SAMPLE_COUNT"] = offset.SampleCount.ToString(CultureInfo.InvariantCulture);
        }

        return processPlan with { Parameters = parameters };
    }

    private static ST_REVIEW_HEAD_OFFSET CreateHeadOffset(
        int headNo,
        IReadOnlyList<ST_REVIEW_MEASUREMENT_POINT> points,
        EN_REVIEW_OFFSET_SOURCE source,
        ST_REVIEW_OFFSET_POLICY policy)
    {
        var averageErrorX = points.Average(point => point.ErrorX);
        var averageErrorY = points.Average(point => point.ErrorY);

        return new ST_REVIEW_HEAD_OFFSET(
            headNo,
            Clamp(-averageErrorX * policy.GainX, policy.MaxAbsOffsetX),
            Clamp(-averageErrorY * policy.GainY, policy.MaxAbsOffsetY),
            0.0,
            points.Count,
            source,
            DateTimeOffset.Now);
    }

    private static double Clamp(double value, double maxAbs)
    {
        var limit = Math.Abs(maxAbs);
        return Math.Clamp(value, -limit, limit);
    }

    private static int ReadInt(
        IReadOnlyDictionary<string, string> parameters,
        string key,
        int defaultValue)
    {
        return parameters.TryGetValue(key, out var value) &&
            int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var result)
                ? result
                : defaultValue;
    }

    private static double ReadDouble(
        IReadOnlyDictionary<string, string> parameters,
        string key,
        double defaultValue)
    {
        return parameters.TryGetValue(key, out var value) &&
            double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out var result)
                ? result
                : defaultValue;
    }

    private static bool ReadBool(
        IReadOnlyDictionary<string, string> parameters,
        string key,
        bool defaultValue)
    {
        if (!parameters.TryGetValue(key, out var value) ||
            string.IsNullOrWhiteSpace(value))
        {
            return defaultValue;
        }

        return value.Trim().ToUpperInvariant() switch
        {
            "1" or "Y" or "YES" or "TRUE" or "ON" or "USE" => true,
            "0" or "N" or "NO" or "FALSE" or "OFF" or "SKIP" => false,
            _ => defaultValue
        };
    }

    private static string Format(double value)
    {
        return value.ToString("0.######", CultureInfo.InvariantCulture);
    }
}
