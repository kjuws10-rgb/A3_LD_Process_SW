using System.Globalization;
using System.IO;
using System.Text;
using Drilling.Common.Alarm;
using Drilling.Common.Interface;
using Drilling.Common.InterLock;
using Drilling.Common.Managers;
using Drilling.Common.Motion;
using Drilling.Common.Station;

namespace Drilling.Common.Interface;

public enum EN_CHILLER_COMMAND
{
    Run,
    Stop,
    PumpOnly,
    SetTemperature,
    ResetAlarm,
    PollLiquidTemp,
    PollSetTemp,
    PollRunState,
    PollAlarmCode
}

public enum EN_CHILLER_RUN_STATE
{
    Stop = 0,
    Run = 1,
    PumpOnly = 2
}

public enum EN_CHILLER_ERROR
{
    Ok = 0,
    Error = 1,
    Timeout = -1,
    InvalidResponse = -2,
    NotSupported = -99
}

[CCommType("Serial", "Chiller")]
[CCommType("ModbusSerial", "Chiller")]
internal sealed class COrionChiller(
    ST_INTERFACE_DATA data,
    ST_INTERFACE_CONNECT_OPTION option) : CSerialComm(data, option)
{
    private const byte Stx = 0x02;
    private const byte Etx = 0x03;
    private const byte Eot = 0x04;
    private const byte Enq = 0x05;
    private const byte Ack = 0x06;
    private const byte Nak = 0x15;
    private const int DataLength = 8;
    private const int DeviceAddress = 0;

    public static string Build(EN_CHILLER_COMMAND command, double parameter)
    {
        return command switch
        {
            EN_CHILLER_COMMAND.Run => "ORION:RUN",
            EN_CHILLER_COMMAND.Stop => "ORION:STOP",
            EN_CHILLER_COMMAND.PumpOnly => "ORION:PUMP",
            EN_CHILLER_COMMAND.SetTemperature => $"ORION:SETTEMP:{parameter.ToString("F1", CultureInfo.InvariantCulture)}",
            EN_CHILLER_COMMAND.ResetAlarm => "ORION:RESETALARM",
            EN_CHILLER_COMMAND.PollLiquidTemp => "ORION:POLL:M1",
            EN_CHILLER_COMMAND.PollSetTemp => "ORION:POLL:S1",
            EN_CHILLER_COMMAND.PollRunState => "ORION:POLL:JO",
            EN_CHILLER_COMMAND.PollAlarmCode => "ORION:POLL:ER",
            _ => ""
        };
    }

    public static bool IsSuccessResponse(string response)
    {
        return !string.IsNullOrWhiteSpace(response) &&
            !response.StartsWith("ERR:", StringComparison.OrdinalIgnoreCase);
    }

    public static ST_ORION_CHILLER_STATUS Apply(
        EN_CHILLER_COMMAND command,
        double parameter,
        string response,
        ST_ORION_CHILLER_STATUS current,
        bool simulation)
    {
        if (command == EN_CHILLER_COMMAND.ResetAlarm)
        {
            return current with
            {
                LastError = EN_CHILLER_ERROR.NotSupported,
                UpdatedAt = DateTimeOffset.Now
            };
        }

        var value = simulation
            ? CreateSimulationResponse(command, parameter, current)
            : response.Trim();

        if (!simulation && !IsSuccessResponse(value))
        {
            return current with
            {
                CommOk = false,
                LastError = ReadError(value),
                UpdatedAt = DateTimeOffset.Now
            };
        }

        var ok = current with
        {
            CommOk = true,
            LastError = EN_CHILLER_ERROR.Ok,
            UpdatedAt = DateTimeOffset.Now
        };

        return command switch
        {
            EN_CHILLER_COMMAND.Run => ok with { RunState = EN_CHILLER_RUN_STATE.Run },
            EN_CHILLER_COMMAND.Stop => ok with { RunState = EN_CHILLER_RUN_STATE.Stop },
            EN_CHILLER_COMMAND.PumpOnly => ok with { RunState = EN_CHILLER_RUN_STATE.PumpOnly },
            EN_CHILLER_COMMAND.SetTemperature => ok with { SetTempC = parameter },
            EN_CHILLER_COMMAND.PollLiquidTemp => ok with { LiquidTempC = ReadPollingDouble(value, "M1") },
            EN_CHILLER_COMMAND.PollSetTemp => ok with { SetTempC = ReadPollingDouble(value, "S1") },
            EN_CHILLER_COMMAND.PollRunState => ok with { RunState = ReadRunState(value) },
            EN_CHILLER_COMMAND.PollAlarmCode => ok with { AlarmCode = ReadPollingData(value, "ER") },
            _ => ok
        };
    }

    public override async Task<string> Execute(
        string function,
        CancellationToken cancellationToken = default)
    {
        await SerialLock.WaitAsync(cancellationToken);

        try
        {
            return await ExecuteOrion(function, cancellationToken);
        }
        finally
        {
            SerialLock.Release();
        }
    }

    private async Task<string> ExecuteOrion(
        string function,
        CancellationToken cancellationToken)
    {
        if (SerialPort is null || !SerialPort.IsOpen)
        {
            await Connect(cancellationToken);
        }

        if (SerialPort is null || !SerialPort.IsOpen)
        {
            return "";
        }

        LastSent = function;

        try
        {
            LastReceived = await Task.Run(() => ExecuteOrion(function), cancellationToken);
            LastError = LastReceived.StartsWith("ERR:", StringComparison.OrdinalIgnoreCase)
                ? LastReceived
                : "";

            SetState(LastReceived.StartsWith("ERR:-1", StringComparison.OrdinalIgnoreCase)
                ? EN_COMM_STATE.Offline
                : EN_COMM_STATE.Online);

            return LastReceived;
        }
        catch (Exception ex) when (ex is InvalidOperationException or IOException or TimeoutException or UnauthorizedAccessException or ObjectDisposedException)
        {
            CloseSerialPort();
            SetError(ex);
            return "";
        }
    }

    private string ExecuteOrion(string function)
    {
        var parts = function.Split(':', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        if (parts.Length < 2 || !parts[0].Equals("ORION", StringComparison.OrdinalIgnoreCase))
        {
            return "ERR:-2";
        }

        return parts[1].ToUpperInvariant() switch
        {
            "RUN" => SendSelecting("JO", CreateRunData(1)),
            "STOP" => SendSelecting("JO", CreateRunData(0)),
            "PUMP" => SendSelecting("JO", CreateRunData(2)),
            "SETTEMP" when parts.Length >= 3 && double.TryParse(
                parts[2],
                NumberStyles.Float,
                CultureInfo.InvariantCulture,
                out var temp) => SendSelecting("S1", FormatTemperatureData(temp)),
            "POLL" when parts.Length >= 3 => SendPolling(parts[2]),
            "RESETALARM" => "ERR:-99",
            _ => "ERR:-2"
        };
    }

    private string SendPolling(string id)
    {
        var id2 = NormalizeId(id);

        if (id2.Length != 2)
        {
            return "ERR:-2";
        }

        var address = FormatAddress();
        var tx = new[]
        {
            Eot,
            (byte)address[0],
            (byte)address[1],
            (byte)id2[0],
            (byte)id2[1],
            Enq
        };

        SerialPort!.DiscardInBuffer();
        SerialPort.DiscardOutBuffer();
        SerialPort.Write(tx, 0, tx.Length);

        var frame = ReadFrame();

        if (frame.Length == 0)
        {
            return "ERR:-1";
        }

        return TryParsePollingFrame(frame, out var responseId, out var data)
            ? $"{responseId}:{data.Trim()}"
            : "ERR:-2";
    }

    private string SendSelecting(string id, string data)
    {
        var id2 = NormalizeId(id);

        if (id2.Length != 2 || data.Length != DataLength)
        {
            return "ERR:-2";
        }

        var address = FormatAddress();
        var body = new List<byte>(2 + DataLength + 1)
        {
            (byte)id2[0],
            (byte)id2[1]
        };
        body.AddRange(Encoding.ASCII.GetBytes(data));
        body.Add(Etx);

        var tx = new List<byte>(1 + 2 + 1 + body.Count + 1)
        {
            Eot,
            (byte)address[0],
            (byte)address[1],
            Stx
        };
        tx.AddRange(body);
        tx.Add(CalcBcc(body));

        SerialPort!.DiscardInBuffer();
        SerialPort.DiscardOutBuffer();
        SerialPort.Write(tx.ToArray(), 0, tx.Count);

        return WaitAck() switch
        {
            0 => "OK",
            -2 => "ERR:-2",
            _ => "ERR:-1"
        };
    }

    private static string CreateRunData(int state)
    {
        var data = new char[DataLength];
        Array.Fill(data, ' ');
        data[0] = (char)('0' + state);
        return new string(data);
    }

    private static string FormatTemperatureData(double celsius)
    {
        if (celsius < 5.0 || celsius > 40.0)
        {
            return "";
        }

        var text = celsius.ToString("0.0", CultureInfo.InvariantCulture);
        return text.Length > DataLength
            ? ""
            : text.PadLeft(DataLength, ' ');
    }

    private static string CreateSimulationResponse(
        EN_CHILLER_COMMAND command,
        double parameter,
        ST_ORION_CHILLER_STATUS current)
    {
        return command switch
        {
            EN_CHILLER_COMMAND.PollLiquidTemp => $"M1:{current.LiquidTempC.ToString("F1", CultureInfo.InvariantCulture)}",
            EN_CHILLER_COMMAND.PollSetTemp => $"S1:{current.SetTempC.ToString("F1", CultureInfo.InvariantCulture)}",
            EN_CHILLER_COMMAND.PollRunState => $"JO:{(int)current.RunState}",
            EN_CHILLER_COMMAND.PollAlarmCode => $"ER:{current.AlarmCode}",
            EN_CHILLER_COMMAND.Run => "OK",
            EN_CHILLER_COMMAND.Stop => "OK",
            EN_CHILLER_COMMAND.PumpOnly => "OK",
            EN_CHILLER_COMMAND.SetTemperature => "OK",
            _ => ""
        };
    }

    private static EN_CHILLER_ERROR ReadError(string response)
    {
        var value = response.StartsWith("ERR:", StringComparison.OrdinalIgnoreCase)
            ? response[4..]
            : "";

        if (!int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var code))
        {
            return EN_CHILLER_ERROR.Error;
        }

        return code switch
        {
            -99 => EN_CHILLER_ERROR.NotSupported,
            -2 => EN_CHILLER_ERROR.InvalidResponse,
            -1 => EN_CHILLER_ERROR.Timeout,
            _ => EN_CHILLER_ERROR.Error
        };
    }

    private static double ReadPollingDouble(string response, string id)
    {
        var data = ReadPollingData(response, id);
        return double.TryParse(
            data,
            NumberStyles.Float,
            CultureInfo.InvariantCulture,
            out var result)
            ? result
            : 0.0;
    }

    private static EN_CHILLER_RUN_STATE ReadRunState(string response)
    {
        var data = ReadPollingData(response, "JO");

        if (string.IsNullOrWhiteSpace(data))
        {
            data = ReadPollingData(response, "J0");
        }

        return data.Trim().StartsWith("2", StringComparison.Ordinal)
            ? EN_CHILLER_RUN_STATE.PumpOnly
            : data.Trim().StartsWith("1", StringComparison.Ordinal)
                ? EN_CHILLER_RUN_STATE.Run
                : EN_CHILLER_RUN_STATE.Stop;
    }

    private static string ReadPollingData(string response, string id)
    {
        var prefix = $"{id}:";
        return response.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
            ? response[prefix.Length..].Trim()
            : response.Trim();
    }

    private byte[] ReadFrame()
    {
        var frame = new List<byte>();

        try
        {
            while (true)
            {
                var value = SerialPort!.ReadByte();

                if (value == Stx)
                {
                    frame.Add((byte)value);
                    break;
                }
            }

            while (true)
            {
                var value = SerialPort!.ReadByte();
                frame.Add((byte)value);

                if (value == Etx)
                {
                    try
                    {
                        frame.Add((byte)SerialPort.ReadByte());
                    }
                    catch (TimeoutException)
                    {
                    }

                    return frame.ToArray();
                }
            }
        }
        catch (TimeoutException)
        {
            return [];
        }
    }

    private int WaitAck()
    {
        try
        {
            while (true)
            {
                var value = SerialPort!.ReadByte();

                if (value == Ack)
                {
                    return 0;
                }

                if (value == Nak)
                {
                    return -2;
                }
            }
        }
        catch (TimeoutException)
        {
            return -1;
        }
    }

    private static bool TryParsePollingFrame(
        IReadOnlyList<byte> frame,
        out string id,
        out string data)
    {
        id = "";
        data = "";

        if (frame.Count < 5 || frame[0] != Stx)
        {
            return false;
        }

        var etxIndex = -1;

        for (var index = 3; index < frame.Count; index++)
        {
            if (frame[index] == Etx)
            {
                etxIndex = index;
                break;
            }
        }

        if (etxIndex < 3)
        {
            return false;
        }

        id = Encoding.ASCII.GetString([frame[1], frame[2]]);
        data = Encoding.ASCII.GetString(frame.Skip(3).Take(etxIndex - 3).ToArray());
        return true;
    }

    private static string NormalizeId(string id)
    {
        return id.Trim().ToUpperInvariant() switch
        {
            "J0" => "JO",
            var value => value
        };
    }

    private static string FormatAddress()
    {
        return DeviceAddress.ToString("00", CultureInfo.InvariantCulture);
    }

    private static byte CalcBcc(IEnumerable<byte> bytes)
    {
        byte bcc = 0x00;

        foreach (var value in bytes)
        {
            bcc ^= value;
        }

        return bcc;
    }
}

public sealed record ST_CHILLER_STATUS(
    bool Running,
    double Temperature,
    double Flow,
    double Pressure,
    bool AlarmOn);

public sealed record ST_ORION_CHILLER_STATUS(
    double LiquidTempC,
    double SetTempC,
    EN_CHILLER_RUN_STATE RunState,
    string AlarmCode,
    bool CommOk,
    EN_CHILLER_ERROR LastError,
    DateTimeOffset? UpdatedAt)
{
    public static ST_ORION_CHILLER_STATUS Empty { get; } = new(
        22.4,
        22.0,
        EN_CHILLER_RUN_STATE.Run,
        "",
        true,
        EN_CHILLER_ERROR.Ok,
        null);
}


